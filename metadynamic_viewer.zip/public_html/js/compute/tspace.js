if(typeof compute==="undefined"){compute={};}
if(typeof compute.tspacer==="undefined"){compute.tspacer={};}
$.extend(compute.tspacer,{
    lastId:0,
    msi:2.8,  // const - multiple of sigma   2=95%
    //tspace:null,
    isWebgl:function(){
        return control.settings.webgl.get()&&control.settings.ncv.get()>1;
    },
    createSpace:function(resol,ncv){   // spacer
        if(!ncv){ncv=control.settings.ncv.get();}
        if(typeof resol==="undefined"){resol=control.settings.resol.get();}
        if(this.isWebgl()){
            if(!compute.gl_summer.init()){return null;};
            var space=$.extend({},this.tspace["gl"+ncv]);
        }else{
            var space=$.extend({},this.tspace[ncv]);
        }
        $.extend(space,{id:this.lastId++});
        space.init(this.multibin(resol,ncv));
        return space;
    },
    createBlob:function(resol,hei){   // spacer
        if(typeof resol==="undefined"){resol=control.settings.resol.get();}
        var sigmas=compute.sum_hill.checkSigmaConst();
        //var sigmas=[0.3,0.3,0.3];
        var sigmas8=[];
        var sigmas1=[];
        var ncv=control.settings.ncv.get();
        for(var i=0;i<ncv;i++){
            sigmas1.push(sigmas[i]*resol/compute.sum_hill.diffs[i]);
            sigmas8.push(Math.floor(sigmas1[i]*this.msi)*2+1);
        }
        if(ncv===1||this.isWebgl()){
            var space=this.createSpace(resol);
        }else{
            var space=this.createSpace(sigmas8);
        }
        space.blob(sigmas1,hei);
        return space;
    },
    multibin:function(nbins,ncv){   // spacer
        if(nbins.length){
            if(nbins.length===ncv){
                return nbins;
            }else{
                manage.console.error("Error: Tspace: wrong length of nbins");
            }
        }else{
            var bins=[];
            for(var i=0;i<ncv;i++){
                bins.push(nbins);
            }
            return bins;
        }
    }
});
if(typeof compute.tspacer.tspace==="undefined"){compute.tspacer.tspace={};}
compute.tspacer.tspace[2]={
    id:0,
    dims:null,
    coefs:null,
    ncv:2,
    nbins:0,
    res:1,
    nwhole:0,
    ratio:0,
    init:function(nbins){
        this.id=this.lastid++;
        var ncv=this.ncv;
        this.nbins=nbins;
        var nwh=1;
        this.coefs=new Int32Array(ncv);
        this.dims=new Int32Array(ncv);
        for(var i=0;i<ncv;i++){
            this.dims[i]=nbins[i];
            this.coefs[i]=nwh;
            nwh*=nbins[i];
        }
        this.nwhole=nwh;
        this.spacearr=new Float32Array(nwh);
    },
    copy:function(){
        var space=$.extend(true,{},this);
        this.id=this.lastid++;
        //space.init(this.nbins,this.ncv);
        space.spacearr=this.copyFloat32Array(this.spacearr);
        space.coefs=this.copyInt32Array(this.coefs);
        space.dims=this.copyInt32Array(this.dims);
        //if(this.spacearr===space.spacearr){manage.console.warning("Storage: Arrays are same");}
        return space;
    },
    copyFloat32Array:function(array){
        if(!array){return null;}
        var nar=new Float32Array(array.length);
        nar.set(array);
        return nar;
    },
    copyInt32Array:function(array){
        if(!array){return null;}
        var nar=new Int32Array(array.length);
        nar.set(array);
        return nar;
    },
    copyUint8Array:function(array){
        if(!array){return null;}
        var nar=new Uint8Array(array.length);
        nar.set(array);
        return nar;
    },
    set:function(space){
        if(this.ncv!==space.ncv){manage.console.error("Storage: Incompatible arrays");return;}
        if(this.nwhole!==space.nwhole){manage.console.error("Storage: Incompatible arrays");return;}
        this.spacearr.set(space.spacearr);
        this.ratio=space.ratio;
        //if(this.spacearr===space.spacearr){manage.console.warning("Storage: Arrays are same");}
    },
    reset:function(){
        this.ratio=-1;
        this.spacearr=new Float32Array(this.nwhole);
    },
    /*all:function(value,typ){
        var len=this.nwhole;
        if(typ==="add"){
            for(var i=0;i<len;i++){
                this.spacearr[i]+=value;
            }
        }else
        if(typ==="multiply"){
            for(var i=0;i<len;i++){
                this.spacearr[i]*=value;
            }
        }else{
            for(var i=0;i<len;i++){
                this.spacearr[i]=value;
            }
        }
    },*/
    plane:function(value,axi,axival,typ){
        var raxi=this.restaxi(axi);
        var c0=raxi[0];
        var axiin=axival*this.coefs[axi];
        var coe0=this.coefs[c0];
        if(typ==="add"){
            for(var i=0;i<this.dims[c0];i++){
                this.spacearr[axiin+i*coe0]+=value;
            }
        }else
        if(typ==="multiply"){
            for(var i=0;i<this.dims[c0];i++){
                this.spacearr[axiin+i*coe0]*=value;
            }
        }else
        {
            for(var i=0;i<this.dims[c0];i++){
                this.spacearr[axiin+i*coe0]=value;
            }
        }
    },
    add:function(inds,space){
        if(this.res!==space.res){
            manage.console.error("Space.add: Variable resolution not implemented");
            return;
        }
        var tdims=this.dims;
        var bdims=space.dims;
        var divis=[false,false,false,false];
        if(!this.templims){
            this.templims=new Float32Array(2*(2+1));
        }
        var lims=this.templims;
        for(var i=0;i<2;i++){
            var icv=3*i;
            lims[icv]=Math.floor(inds[i]*tdims[i])-(bdims[i]-1)/2;
            lims[icv+1]=Math.floor(inds[i]*tdims[i])+(bdims[i]-1)/2+1;
            lims[icv+2]=0;
            if(lims[icv]<0){lims[icv+2]=-lims[icv];lims[icv]=0;divis[i*2]=true;}
            if(lims[icv+1]>tdims[i]){lims[icv+1]=tdims[i];divis[i*2+1]=true;}
        }
        var hei=inds[2];
        //var lims=this.computeLims(inds,space);
        var len0=lims[1]-lims[0];
        var len1=lims[4]-lims[3];
        if(len0<1||len1<1){return;}
        var tcoef=this.coefs;var bcoef=space.coefs;
        var tp=lims[0]*tcoef[0]+lims[3]*tcoef[1];
        var bp=lims[2]*bcoef[0]+lims[5]*bcoef[1];
        var tp1,bp1;
        for(var j=0;j<len1;j++){
            tp1=tp+tcoef[1]*j;
            bp1=bp+bcoef[1]*j;
            for(var i=0;i<len0;i++){
                //this.spacearr[tcoef[0]*(lims[0]+i)+tcoef[1]*(lims[3]+j)]+=space.spacearr[bcoef[0]*(lims[2]+i)+bcoef[1]*(lims[5]+j)];
                this.spacearr[tp1+tcoef[0]*i]+=hei*space.spacearr[bp1+bcoef[0]*i];
            }
        }
        return divis;
    },
    
    sum:function(space){
        var len=space.length;
        for(var i=0;i<len;i++){
            this.spacearr[i]+=space.spacearr[i];
        }
        return this; 
    },
    isEmpty:function(){
        var len=this.nwhole;
        for(var i=0;i<len;i++){
            if(this.spacearr[i]!==0){return false;}
        }
        return true; 
    },
    restaxi:function(axi){
        var raxi=[];
        for(var i=0;i<this.ncv;i++){
            if(i!==axi){raxi.push(i);}
        }
        return raxi;
    },
    blob:function(sigmastep,hei){
        for(var c=0;c<this.ncv;c++){
            var dim2=Math.floor((this.dims[c]-1)/2);
            var sigma=sigmastep[c];
            for(var i=-dim2;i<=dim2;i++){
                var val=Math.pow(i/sigma,2);
                this.plane(val,c,i+dim2,"add");
            }
        }
        var len=this.nwhole;
        for(var i=0;i<len;i++){
            this.spacearr[i]=hei*Math.exp(-this.spacearr[i]/2);
        }
    },
    /*print:function(){
        var canvas=$("<canvas>").attr({width:this.dims[0],height:this.dims[1]});
        var len=this.nwhole;
        var data=new Uint8ClampedArray(len*4);
        var hei=1;var sig=0.03;
        var ctx=canvas[0].getContext("2d");
        //var data=imageData.data;
        for(var i=0;i<len;i++){
            
            data[4*i]=255*Math.exp(-Math.pow(this.spacearr[i]/hei-0.8,2)/sig);
            data[4*i+1]=255*Math.exp(-Math.pow(this.spacearr[i]/hei-0.5,2)/sig);
            data[4*i+2]=255*Math.exp(-Math.pow(this.spacearr[i]/hei-0.2,2)/sig);
            data[4*i+3]=255;
        }
        var imageData=ctx.createImageData(this.dims[0],this.dims[1]);
        imageData.data.set(data);
        ctx.putImageData(imageData,0,0);
        return canvas;
    },*/
    getArr:function(){
        return this.spacearr;
    },
    getDrawable:function(){
        return new Float32Array(this.nwhole);
    },
    compute:function(){}
};
compute.tspacer.tspace[3]={
    init:function(){
        manage.console.error("Error: More than 2 CVs is not implemented");
    },
    add3:function(inds,space){
        if(this.res!==space.res){
            manage.console.error("Space.add: Variable resolution not implemented");
            return;
        }
        var tdims=this.dims;
        var bdims=space.dims;
        var lims=new Float32Array(3*(2+1));
        for(var i=0;i<3;i++){
            var icv=3*i;
            lims[icv]=Math.floor(inds[i]*tdims[i])-(bdims[i]-1)/2;
            lims[icv+1]=Math.floor(inds[i]*tdims[i])+(bdims[i]-1)/2+1;
            lims[icv+2]=0;
            if(lims[icv]<0){lims[icv+2]=-lims[icv];lims[icv]=0;}
            if(lims[icv+1]>tdims[i]){lims[icv+1]=tdims[i];}
        }
        var len0=lims[1]-lims[0];
        var len1=lims[3+1]-lims[3];
        var len2=lims[6+1]-lims[6];
        var tcoef=this.coefs;var bcoef=space.coefs;
        for(var i=0;i<len0;i++){
            for(var j=0;j<len1;j++){
                for(var k=0;k<len2;k++){
                    this.spacearr[tcoef[0]*(lims[0]+i)+tcoef[1]*(lims[3]+j)+tcoef[2]*(lims[6]+k)]+=space.spacearr[bcoef[0]*(lims[2]+i)+bcoef[1]*(lims[5]+j)+bcoef[2]*(lims[8]+k)];
                }
            }
        }
        
    },
    plane3:function(value,axi,axival,typ){
        var raxi=this.restaxi(axi);
        var c0=raxi[0];
        var c1=raxi[1];
        var axiin=axival*this.coefs[axi];
        var coe0=this.coefs[c0];
        var coe1=this.coefs[c1];
        if(typ==="add"){
            for(var i=0;i<this.dims[c0];i++){
                for(var j=0;j<this.dims[c1];j++){
                    this.spacearr[axiin+i*coe0+j*coe1]+=value;
                }
            }
        }else
        if(typ==="multiply"){
            for(var i=0;i<this.dims[c0];i++){
                for(var j=0;j<this.dims[c1];j++){
                    this.spacearr[axiin+i*coe0+j*coe1]*=value;
                }
            }
        }else
        {
            for(var i=0;i<this.dims[c0];i++){
                for(var j=0;j<this.dims[c1];j++){
                    this.spacearr[axiin+i*coe0+j*coe1]=value;
                }
            }
        }
    }
};

